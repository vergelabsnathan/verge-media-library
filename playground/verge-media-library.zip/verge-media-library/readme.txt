=== Verge Media Library ===
Contributors: vergelabsnathan
Tags: media library, media folders, media tags, media categories, mime types
Requires at least: 6.5
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 2.9.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Categories, tags and custom taxonomies for the media library. A maintained fork of Enhanced Media Library, repaired for WordPress 7.

## Description ##

**Handy for those who need to manage a lot of media files.**

Verge Media Library is a maintained fork of [Enhanced Media Library](https://wordpress.org/plugins/enhanced-media-library/) by wpUXsolutions, which has had no release since July 2024. It repairs the media toolbar on WordPress 7.0 and clears the PHP 8 warnings. Everything else is the plugin you already know.

Based on Enhanced Media Library by wpUXsolutions, and licensed GPLv2 or later as the original is.

[Source and issue tracker](https://github.com/vergelabsnathan/verge-media-library)


### What this fork fixes ###

* **The WordPress 7.0 toolbar layout.** WP 7.0 turned the media toolbar into a fixed two-column CSS grid and gave placement to its own two filters only. The extra filters this plugin adds had nowhere to go, so they stacked into a 300px-tall block with every label sitting above the wrong control. The toolbar is one tidy row again, whatever number of filters you enable.
* **The author filter drew on top of the type filter.** It rendered with the same HTML id as the type filter, which was invisible under the old layout but made the two overlap once WordPress started placing elements by id. It now uses the id its own label was already pointing at, which fixes the overlap and the mislabelled control together.
* **PHP 8 warnings.** The four settings handlers read their nonce field before checking whether it was there. Also four `get_terms()` calls still using the argument order deprecated back in WordPress 4.5.

### Moving over from Enhanced Media Library ###

Activating this plugin copies your existing Enhanced Media Library settings across: taxonomies, MIME types, library and filter options. The originals are left untouched, so nothing is lost if you switch back. Deactivate Enhanced Media Library before activating this one, since running both at once means two copies of the same taxonomies.


### Categorize by Anything! ###

* Unlimited **categories & tags** for media items
* Unlimited **custom taxonomies:** create in a few clicks
* Unlimited **third-party taxonomies:** assign to the media library


### Configurable Filters ###

* **Show / hide** data, author, taxonomy filters
* **Per taxonomy** filters
* **Configurable outcome** of the filtering: include / exclude child categories


### Enhanced Media Library ###

* **Show captions:** title, filename, or caption field for each media item
* **Bulk selection:** no special mode anymore, faster editing
* **Drag'n'Drop re-order** right in the media library
* **Infinite scroll** and manageable loads per page options


### Dynamic Galleries / Playlists ###

Additional parameters for the [gallery] and [playlist] shortcodes:

* `media_category` or any other taxonomy
* `monthnum`
* `year`
* `limit` of media items to show


### MIME Types Management ###

Add or remove file types, allow or disallow uploading. The plugin incorporates a file type into media filters if you wish.


### Feels Native to WordPress ###

We spent hours to make Enhanced Media Library operates as though it were native WordPress functionality. All plugin features are incorporated into WordPress UI seamlessly.


### Developer-Friendly ###

* **Core hooks just work** for media taxonomies and media items
* **All taxonomies supported:** custom and code-registered
* **REST API supported** out of the box
* **No custom tables** in the database
* **Deactivation makes no harm to data:** all media items and taxonomies remain after deactivation


### Export / Import / Restore Plugin Settings ###

If you need to move your media library to another website you should export and import WordPress content with WordPress built-in export/import. But to make the Enhanced Media Library work on the new site with the same settings you are provided with the export/import feature.


### Multisite compatible ###

Network activate the plugin and choose which options will be available to your admins. In the PRO version, the license key should be activated once for the whole network.

[More about the basic version on wpUXsolutions.com](https://www.wpuxsolutions.com/plugins/enhanced-media-library)


### Enhanced Media Library PRO ###

Additional comfort and even more convenient way to organize WordPress media library:

* **Unlimited & Super-Fast** Bulk Edit
* **User-friendly** dynamic galleries / playlists: all options set with dropdowns and checkboxes, no "coding"
* **Advanced search:** filter media items by just typing the first letters of its name in the search field
* **Auto-Categorize** for post media items

[More about the premium version on wpUXsolutions.com](https://www.wpuxsolutions.com/plugins/enhanced-media-library-pro)


### Support ###

Support is free for both versions of the plugin. "PRO"-users do not have priority. We do our best to respond in 24 hours if not sooner.


### Compatible with the Plugins: ###

* [Advanced Custom Fields](https://wordpress.org/plugins/advanced-custom-fields/)
* [WooCommerce](https://wordpress.org/plugins/woocommerce/)
* [FooGallery](https://wordpress.org/plugins/foogallery/) - [How to use?](https://wpuxsolutions.com/documents/enhanced-media-library/how-to-create-a-dynamic-foogallery)
* [Anything Order by Terms](https://wordpress.org/plugins/anything-order-by-terms/)
* [Search & Filter](https://wordpress.org/plugins/search-filter/)
* [Document Gallery](https://wordpress.org/plugins/document-gallery/)
* [Jetpack Carousel](https://wordpress.org/plugins/jetpack/)
* [Jetpack Tiled Galleries](https://wordpress.org/plugins/jetpack/)
* [Simple Lightbox](https://wordpress.org/plugins/simple-lightbox/)
* [Justified Gallery](https://wordpress.org/plugins/justified-gallery/)
* [Meow Gallery](https://wordpress.org/plugins/meow-gallery/)
* [Meow Lightbox](https://wordpress.org/plugins/meow-lightbox/)
* [MetaSlider](https://wordpress.org/plugins/ml-slider/)
* [Responsive Lightbox & Gallery](https://wordpress.org/plugins/responsive-lightbox/)
* [Compress JPEG & PNG Images](https://wordpress.org/plugins/tiny-compress-images/) (TinyPNG)


Please let us know if you find any issue with the plugins from the list above or others.


### Incompatibility ###

Please notice that you use Enhanced Media Library with other plugins that add media categories, media folders, or manage MIME Types at your own risk. We cannot guarantee their compatibility because of the different approaches to the same functionality. We do not recommend using other media library (folder) plugin at the same time with the Enhanced Media Library. Please choose the one you prefer.


### Useful Links ###

* [Basic version: more details](https://wpuxsolutions.com/plugins/enhanced-media-library)
* [PRO version: more details](https://wpuxsolutions.com/plugins/enhanced-media-library-pro)
* [Documentation](https://www.wpuxsolutions.com/documents/enhanced-media-library)
* [FAQs](https://www.wpuxsolutions.com/documents/enhanced-media-library/faqs)


## Installation ##

1. Upload plugin folder to '/wp-content/plugins/' directory

2. Activate the plugin through `Plugins` menu in WordPress admin

3. Adjust plugin's settings on `Settings > Media`

4. Enjoy Enhanced Media Library!



## Frequently Asked Questions ##

> [FAQs](https://www.wpuxsolutions.com/documents/enhanced-media-library/faqs-2/) | [Documentation](https://www.wpuxsolutions.com/documents/enhanced-media-library/)



## Screenshots ##

1. Plugin Settings: WordPress General Media Settings

2. Plugin Settings: Media Items Order & Enhanced Media Shortcodes

3. Plugin Settings: Media Taxonomies & Filters

4. Plugin Settings: MIME Types settings

5. Plugin Settings: Export, Import, Restore, Cleanup

6. Media Taxonomies are just usual WordPress taxonomies

7. Media categories and tags in Nav Menu

8. Media Library Grid Mode

9. Media Library List Mode

10. Editing individual image / media items

11. Filter-based image gallery



## Changelog ##

### 2.9.6 ###
*Security and isolation pass*

= Security =
* The AJAX handler that applies settings across a multisite network verified a nonce but no capability. It now requires `manage_network_options`. Not cleanly exploitable before, since the nonce is only printed on a super-admin screen, but the nonce was the only thing standing between a lower-privileged user and network-wide option writes.

= Bugfixes =
* Script and style handles, CSS classes and DOM ids still carried the upstream `wpuxss-eml-` prefix, which the 2.9.5 rename missed because it only moved the underscore form. The style handle in particular would have collided with Enhanced Media Library and left one plugin's assets unloaded. All moved to `vergeml-`.
* The three custom AJAX actions were still unprefixed, so both plugins would have answered the same request. Now `vergeml-*`.
* Admin menu and page titles still read "Enhanced Media Library Utilities" and "EML Utilities".

### 2.9.5 ###
*First release of the Verge Media Library fork*

= Bugfixes =
* Media toolbar layout repaired on WordPress 7.0. Core made `.media-toolbar-secondary` a fixed 2x2 CSS grid and placed only its own two filters explicitly; every control this plugin adds fell into implicit auto-placement and stacked below the toolbar with labels attached to the wrong controls. Measured on WP 7.0.4, the toolbar goes from 300px and six grid rows back to 66px and two.
* The author filter rendered with the same HTML id as the type filter. Under the new id-based placement both were assigned the same grid cell and drew on top of each other, hiding the type filter. The author filter now uses the id its label already referenced, which also reconnects that label to the right control.
* Undefined array key warnings on PHP 8 from the settings export, import, restore and cleanup handlers, which read their nonce field before checking it existed. With WP_DEBUG on, each also produced a run of "Cannot modify header information" warnings.
* Four `get_terms()` calls updated from the taxonomy-first signature deprecated in WordPress 4.5.

= Fork notes =
* Renamed from Enhanced Media Library, with all functions, classes, options and hooks moved off the `wpuxss_eml_` prefix so both plugins can be installed without a fatal redeclaration.
* Activation copies existing Enhanced Media Library settings across, leaving the originals in place.

### 2.9.4 ###
*Release Date - July 15, 2024*

= Improvement = 
* Validation and transliteration on the Media Taxonomies admin page improved, minor bugs fixed

= Bugfixes =
* A fatal error bug while JetPack VideoPress syncing is probably fixed, requires confirmation

= 3.0 Early Beta is available for testing! =
* [Take a look &raquo;](https://wpuxsolutions.com/blog/enhanced-media-library-3-0-is-coming)

= SECURITY UPDATE =
* Security issue related to MIME types upload has been fixed since v2.8.10. Please update to the latest version on all your websites.

= Notes =
* EML is compatible with PHP 5.6, 7, and 8. Don't hesitate to update. If you previously had issues because of the PHP version, it's not the case anymore.

= Thank you! =
For being EML users for so many years.
* *This update has been issued in Ukraine under everyday missile attacks.*
* *Please do not buy into ruzzian lies and propaganda. This aggression is unprovoked, illegal, and unfair. The people of Ukraine have all the right to live peacefully without ungrounded ruzzian claims and crimes committed.* 
* *Support Ukraine. It would be self-deception to believe that a neighboring country with the Nazi and anti-Western ideology, they are raising their young in, is heavily militarizing its economy and population so as never to pose a threat and never to attack the West.*


### 2.9.3 ###
*Release Date - June 19, 2024*

= Improvement = 
* `xlsm` file type upload ensured if allowed


### 2.9.2 ###
*Release Date - June 14, 2024*

= Bugfixes =
* Elementor compatibility bug of v2.9.1 (not showing filters in Elementor's media popup) fixed


### 2.9.1 ###
*Release Date - May 27, 2024*

= New =
* WP native search performance improved for both free and PRO versions in Media Library Grid Mode
* PRO only: new options added: `Search on enter`, `Auto search`, and `Minimun number of letters`

= Bugfixes =
* PRO only: plugin update module PHP-warnings issue fixed


### 2.9 ###
*Release Date - May 16, 2024*

= New =
* `Uploaded to this post by default` option added to the `Media` > `Media Library` > `Filters` section
  *Enable the option to get media files initially filtered by "Uploaded to this post" in a Media Popup while adding or editing them for a post, page, or custom post type.*
* Some changes made to the plugin's code and the PRO version updating mechanism in preparation for an upcoming major update EML v3.0

= Bugfixes =
* Tiny bugs fixed


### 2.8.15 ###
*Release Date - May 10, 2024*

= Improvements =
* Gallery / playlist shortcodes improved for better compatibility with other plugins
* `AND` logic within a single taxonomy implemented for `[gallery]` and `[playlist]` shortcodes

***Examples:***

`[gallery media_category="california+flowers" genre="landscape"]`
*— Displays images having **both** categories "california" **AND** "flowers" AND also from the genre "landscape"*

`[gallery media_category="flowers,mosses" genre="garden"]`
*— Displays imager **either** from "flowers" **OR** "mosses" category AND also from the genre "garden"*

*Note: For performance it's better to use IDs instead of slugs in the gallery shortcodes.*

= Bugfixes =
* Layout issues fixed for the **media popup** with the `Infinite scrolling` option enabled
* `Fatal Error – Too Few Arguments to function` fixed for two plugins: "cred-frontend-editor" and AJAX Thumbnail Rebuild
* Minor CSS fixes


### 2.8.14 ###
*Release Date - April 30, 2024*

= Improvements =
* Divi Builder compatibility ensured on uploading font files
*Note: Font files are allowed for upload with Divi Builder even if you haven't added them with the EML settings because Divi adds its own allowed file types.*


### 2.8.13 ###
*Release Date - April 26, 2024*

= Bugfixes =
* A bug since v2.8.10 with the right sidebar covering media library files when `Infinite scrolling` option is enabled fixed


### 2.8.12 ###
*Release Date - April 23, 2024*

= Bugfixes =
* A critical error bug of v2.8.11 with filtering by media taxonomies in the media library List View fixed


### 2.8.11 ###
*Release Date - April 19, 2024*

= Improvements =
* Database queries for taxonomies improved
* A mechanism for vetting allowed mime types added

= Bugfixes =
* Deprecated notices for author filter fixed
* Issue with uploading font mime types fixed (Report other mime types you experience issues uploading, please)
* PRO only: Search issue fixed and the mechanism improved to ensure compatibility with other plugins


### 2.8.10 ###
*Release Date - April 11, 2024*

= Improvements =
* Plugin admin menu items order and compatibility improved
* `Right sidebar width` and `Ideal column width` options added
* Caption (grid mode) is no longer cropped when it is a filename
* Caption lenght before crop depends on the thumbnail side - added
* PRO only: Enhanced search mechanism in media library improved + `filenames` option added
* Minor improvements to desltop/mobile layout made
* PHP 8 compatibility ensured (no deprecated notices anymore)
* Latest jQuery standards compatibility ensured (no deprecated notices anymore)

= Bugfixes =
* Duplicate listings when editing a single image edit in the list mode fixed
* WP excess utility taxonomies hidden in the settings


### 2.8.9 ###
*Release Date - January 09, 2022*

= Improvements =
* Infinite scroll and manageable loads per page options added
* SVG full support ensured
* Taxonomy archive pages improved - are now fully disabled and not indexed if chosen 
* Compatibility with SimpLy Gallery Blocks plugin added


### 2.8.8 ###
*Release Date - August 26, 2021*

= Improvements =
* Media Library Grid Mode: "More Details" / "Less Details" button improved to remember the latest choice after page reload
* Better third-party admin menu compatibility
* Compatibility for Impreza theme categories added


### 2.8.7 ###
*Release Date - August 8, 2021*

= Compatibility =
* Enfold theme masonry gallery (latest version) compatibility ensured

= Bugfixes =
* Edit image wrong link fixed for the Grid mode


### 2.8.6 ###
*Release Date - August 5, 2021*

= Compatibility =
* WordPress 5.8 compatibility ensured

= Bugfixes =
* A minor ACF-related bug fixed


### 2.8.5 ###
*Release Date - April 10, 2021*

= Bugfixes =
* A critical bug of v2.8.4 fixed (FooGallery related)
* A few minor bugs fixed


### 2.8.4 ###
*Release Date - April 9, 2021*

= Bugfixes =
* A bug with a category checkbox not showing unchecked after deselecting a category fixed
* A bug with taxonomy archive pages are being actually empty instead of 404 fixed

= Compatibility =
* FooGallery compatibility with EML dynamic galleries added, see [how to use Dynamic FooGalleries](https://wpuxsolutions.com/documents/enhanced-media-library/how-to-create-a-dynamic-foogallery)


### 2.8.3 ###
*Release Date - March 9, 2021*

= Improvements =
* Taxonomy archive pages mechanism improved. When the pages are disabled (404) they are no more accessible by friendly URLs

= Compatibility =
* WordPress 5.7 compatibility ensured


### 2.8.2 ###
*Release Date - December 9, 2020*

= Compatibility =
* WordPress 5.0 - 5.6 minor compatibility issues resolved


### 2.8.1 ###
*Release Date - October 29, 2020*

= Bugfixes =
* Enfold theme compatibility error fixed
* The bug with ACF's panel expand fixed 
* Minor bugs fixed

= Improvements =
* Allowed MIME Types upload improved
* Scroll to a selected media item improved (Media Library Grid Mode)
* PRO only: Faster Select All


### 2.8 ###
*Release Date - October 11, 2020*

= Bugfixes =
* Critical WP core compatibility issues fixed
* Gallery and Playlist editing bug fixed
* Image uploading issue fixed

= Improvements =
* ACF attachment custom fields - better compatibility
* Enfold Theme: added `[av_masonry_gallery]` shortcode compatibility with media category parameters like `media_category='10'`, `tag='21'`
* PRO only: The bulk Save Changes button is disabled by default since v2.8 for new plugin installations. All changes are being made on the fly. If you prefer the button, you can enable it at Settings > Media Taxonomies > Bulk Edit > Save Changes button. 


### Previous releases... ###
