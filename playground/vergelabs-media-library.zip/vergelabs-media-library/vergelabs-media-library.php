<?php
/*
Plugin Name: VergeLabs Media Library
Plugin URI: https://github.com/vergelabsnathan/vergelabs-media-library
Description: Categories, tags and custom taxonomies for the media library, MIME type management, and configurable media grid filters.
Version: 2.10.0
Requires at least: 6.5
Requires PHP: 7.4
Author: VergeLabs
Author URI: https://github.com/vergelabsnathan
Text Domain: vergelabs-media-library
Domain Path: /languages
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Based on Enhanced Media Library by wpUXsolutions.
https://wordpress.org/plugins/enhanced-media-library/

Copyright 2013-2024 wpUXsolutions  (original work)
Copyright 2026 VergeLabs  (modifications)

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.
*/



if ( ! defined( 'ABSPATH' ) )
    exit;



if ( ! defined('VERGEML_VERSION') ) define( 'VERGEML_VERSION', '2.10.0' );



global $vergeml_dir,
       $vergeml_slug,
       $vergeml_filename,
       $vergeml_basename;



if ( ! function_exists( 'vergeml_get_slug' ) ) {


    /**
     *  vergeml_get_slug
     *
     *  keeping the name for older versions compatibility
     * 
     *  @since    2.1
     *  @since    2.9 modified
     *  @created  27/10/15
     */

    function vergeml_get_slug() {

        $path_array = explode( '/', dirname( __FILE__ ) );
        $slug = end( $path_array );

        return $slug;
    }



    /**
     *  vergeml_get_basename
     *
     *  @since    2.1
     *  @since    2.8.16 modified
     *  @created  27/10/15
     */

    function vergeml_get_basename() {

        global $vergeml_basename;

        return $vergeml_basename;
    }



    /**
     *  vergeml_enhance_media_shortcodes
     *
     *  @since    2.1.4
     *  @created  08/01/16
     */

    function vergeml_enhance_media_shortcodes() {

        $vergeml_lib_options = get_option( 'vergeml_lib_options', array() );

        $enhance_media_shortcodes = isset( $vergeml_lib_options['enhance_media_shortcodes'] ) ? (bool) $vergeml_lib_options['enhance_media_shortcodes'] : false;

        return $enhance_media_shortcodes;
    }



    /**
     *  vergeml_enable_infinite_scrolling
     *
     *  @since    2.9
     *  @created  09/2021
     */

    function vergeml_enable_infinite_scrolling() {

        $vergeml_lib_options = get_option( 'vergeml_lib_options', array() );

        $enable_infinite_scrolling = isset( $vergeml_lib_options['infinite_scrolling'] ) ? (bool) $vergeml_lib_options['infinite_scrolling'] : false;

        return $enable_infinite_scrolling;
    }



    /**
     *  vergeml_on_activation
     *
     *  @since    2.7
     *  @created  31/08/18
     */

    register_activation_hook( __FILE__, 'vergeml_on_activation' );

    function vergeml_on_activation() {

        // carry settings over from Enhanced Media Library, if it left any
        vergeml_migrate_legacy_options();

        // per site
        // main site if multisite
        vergeml_set_options();


        if ( is_multisite() && is_network_admin() ) {

            // network options
            vergeml_set_network_options();

            // common (site) options
            do_action( 'vergeml_set_site_options' );
        }
    }



    /**
     *  vergeml_migrate_legacy_options
     *
     *  Carries settings over from Enhanced Media Library, whose option names
     *  this plugin used before the fork was renamed. Copies a value only when
     *  this plugin has none of its own yet, and never removes the originals,
     *  so Enhanced Media Library still works if someone switches back.
     *
     *  @since    2.9.5
     */

    function vergeml_migrate_legacy_options() {

        $legacy = array(
            'wpuxss_eml_version'     => 'vergeml_version',
            'wpuxss_eml_lib_options' => 'vergeml_lib_options',
            'wpuxss_eml_taxonomies'  => 'vergeml_taxonomies',
            'wpuxss_eml_tax_options' => 'vergeml_tax_options',
            'wpuxss_eml_mimes'       => 'vergeml_mimes',
            'wpuxss_eml_backup'      => 'vergeml_backup'
        );

        foreach ( $legacy as $old_name => $new_name ) {

            if ( false !== get_option( $new_name, false ) )
                continue;

            $value = get_option( $old_name, false );

            if ( false !== $value )
                update_option( $new_name, $value );
        }


        if ( is_multisite() && false === get_site_option( 'vergeml_network_options', false ) ) {

            $network_options = get_site_option( 'wpuxss_eml_network_options', false );

            if ( false !== $network_options )
                update_site_option( 'vergeml_network_options', $network_options );
        }
    }



    /**
     *  vergeml_on_plugins_loaded
     *
     *  @since    2.6.1
     *  @since    2.9 modified
     *  @created  20/05/18
     */

    add_action( 'plugins_loaded', 'vergeml_on_plugins_loaded' );

    function vergeml_on_plugins_loaded() {

        global $vergeml_dir,
               $vergeml_slug,
               $vergeml_filename,
               $vergeml_basename;


        $vergeml_dir      = plugin_dir_url( __FILE__ );
        $vergeml_slug     = vergeml_get_slug();
        $vergeml_filename = basename( __FILE__ );
        $vergeml_basename = $vergeml_slug . '/' . $vergeml_filename;


        // on update
        if ( VERGEML_VERSION !== get_option( 'vergeml_version', '' ) ) {
            vergeml_on_activation();
            update_option( 'vergeml_version', VERGEML_VERSION );
            delete_site_transient( 'eml_transient' );
        }


        // plugin action links
        add_filter( 
            'plugin_action_links_' . vergeml_get_basename(),
            'vergeml_settings_link', 10, 4 
        );
        add_filter( 
            'network_admin_plugin_action_links_' . vergeml_get_basename(),
            'vergeml_settings_link', 10, 4 
        );

        add_filter( 'plugin_row_meta', 'vergeml_plugin_row_meta', 10, 4 );
    }



    /**
     *  vergeml_on_init
     *
     *  @since    1.0
     *  @created  03/08/13
     */

    add_action( 'init', 'vergeml_on_init', 12 );

    function vergeml_on_init() {

        $vergeml_taxonomies = get_option( 'vergeml_taxonomies', array() );
        $vergeml_tax_options = get_option( 'vergeml_tax_options', array() );

        // register eml taxonomies
        foreach ( (array) $vergeml_taxonomies as $taxonomy => $params ) {

            if ( $params['eml_media'] && ! empty( $params['labels']['singular_name'] ) && ! empty( $params['labels']['name'] ) ) {

                $labels = array_map( 'sanitize_text_field', $params['labels'] );

                if ( (bool) $vergeml_tax_options['tax_archives'] ) {

                    $rewrite = array(
                        'slug' => vergeml_sanitize_slug( $params['rewrite']['slug'], $taxonomy ),
                        'with_front' => (bool) $params['rewrite']['with_front']
                    );
                    $public = true;
                }
                else {
                    $rewrite = $public = false;
                }

                register_taxonomy(
                    $taxonomy,
                    'attachment',
                    array(
                        'labels'                => $labels,
                        'public'                => $public,
                        'show_ui'               => true,
                        'show_admin_column'     => (bool) $params['show_admin_column'],
                        'hierarchical'          => (bool) $params['hierarchical'],
                        'update_count_callback' => 'vergeml_update_attachment_term_count',
                        'sort'                  => (bool) $params['sort'],
                        'show_in_rest'          => (bool) $params['show_in_rest'],
                        'query_var'             => sanitize_key( $taxonomy ),
                        'rewrite'               => $rewrite
                    )
                );
            }
        } // endforeach
    }



    /**
     *  vergeml_on_wp_loaded
     *
     *  @since    1.0
     *  @created  03/11/13
     */

    add_action( 'wp_loaded', 'vergeml_on_wp_loaded' );

    function vergeml_on_wp_loaded() {

        global $wp_taxonomies;

        $vergeml_taxonomies = get_option( 'vergeml_taxonomies', array() );
        $taxonomies = get_taxonomies( array(), 'object' );

        // discover 'foreign' taxonomies
        foreach ( $taxonomies as $taxonomy => $params ) {

            if ( ! empty( $params->object_type ) && ! array_key_exists( $taxonomy, $vergeml_taxonomies ) &&
                 ! in_array( 'revision', $params->object_type ) &&
                 ! in_array( 'nav_menu_item', $params->object_type ) &&
                 $taxonomy !== 'wp_theme' &&
                 $taxonomy !== 'post_format' &&
                 $taxonomy !== 'link_category' &&
                 $taxonomy !== 'wp_pattern_category' &&
                 $taxonomy !== 'wp_template_part_area' ) {

                $vergeml_taxonomies[$taxonomy] = array(
                    'eml_media' => 0,
                    'admin_filter' => 1, // since 2.7
                    'media_uploader_filter' => 1, // since 2.7
                    'media_popup_taxonomy_edit' => 0,
                    'taxonomy_auto_assign' => 0
                );

                if ( in_array('attachment',$params->object_type) )
                    $vergeml_taxonomies[$taxonomy]['assigned'] = 1;
                else
                    $vergeml_taxonomies[$taxonomy]['assigned'] = 0;
            }
        }

        // assign/unassign taxonomies to atachment
        foreach ( $vergeml_taxonomies as $taxonomy => $params ) {

            $taxonomy = sanitize_key($taxonomy);

            if ( (bool) $params['assigned'] )
                register_taxonomy_for_object_type( $taxonomy, 'attachment' );

            if ( ! (bool) $params['assigned'] )
                unregister_taxonomy_for_object_type( $taxonomy, 'attachment' );
        }


        /**
         *  Clean up update_count_callback
         *  Set custom update_count_callback for post type
         *
         *  @since 2.3
         */
        foreach ( $taxonomies as $taxonomy => $params ) {

            if ( in_array( 'attachment', $params->object_type ) &&
                 isset( $wp_taxonomies[$taxonomy]->update_count_callback ) &&
                 '_update_generic_term_count' === $wp_taxonomies[$taxonomy]->update_count_callback ) {

                unset( $wp_taxonomies[$taxonomy]->update_count_callback );
            }

            if ( in_array( 'post', $params->object_type ) ) {

                if ( in_array( 'attachment', $params->object_type ) )
                    $wp_taxonomies[$taxonomy]->update_count_callback = 'vergeml_update_post_term_count';
                else
                    unset( $wp_taxonomies[$taxonomy]->update_count_callback );
            }
        }

        update_option( 'vergeml_taxonomies', $vergeml_taxonomies );
    }



    /**
     *  vergeml_admin_enqueue_scripts
     *
     *  @since    1.1.1
     *  @created  07/04/14
     */

    add_action( 'admin_enqueue_scripts', 'vergeml_admin_enqueue_scripts' );

    function vergeml_admin_enqueue_scripts() {

        global $vergeml_dir,
               $current_screen;


        $media_library_mode = get_user_option( 'media_library_mode', get_current_user_id() ) ? get_user_option( 'media_library_mode', get_current_user_id() ) : 'grid';

        $vergeml_lib_options = get_option( 'vergeml_lib_options' );


        // admin styles
        wp_enqueue_style(
            'vergeml-admin-custom-style',
            $vergeml_dir . 'css/eml-admin.css',
            false,
            VERGEML_VERSION,
            'all'
        );
        wp_style_add_data( 'vergeml-admin-custom-style', 'rtl', 'replace' );

        // media styles
        wp_enqueue_style(
            'vergeml-admin-media-style',
            $vergeml_dir . 'css/eml-admin-media.css',
            false,
            VERGEML_VERSION,
            'all'
        );
        wp_style_add_data( 'vergeml-admin-media-style', 'rtl', 'replace' );


        wp_enqueue_style ( 'wp-jquery-ui-dialog' );


        // admin scripts
        wp_enqueue_script(
            'vergeml-admin-script',
            $vergeml_dir . 'js/eml-admin.js',
            array( 'jquery', 'jquery-ui-dialog', 'underscore' ),
            VERGEML_VERSION,
            true
        );

        $admin_l10n = array(
            'admin_notice_nonce' => wp_create_nonce( 'eml-admin-notice-nonce' )
        );

        wp_localize_script(
            'vergeml-admin-script',
            'vergeml_admin_l10n',
            $admin_l10n
        );


        // scripts for list view :: /wp-admin/upload.php
        if ( isset( $current_screen ) && 'upload' === $current_screen->base && 'list' === $media_library_mode ) {

            wp_enqueue_script(
                'vergeml-media-list-script',
                $vergeml_dir . 'js/eml-media-list.js',
                array('jquery'),
                VERGEML_VERSION,
                true
            );

            $media_list_l10n = array(
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only: the list view rebuilds its own filter links from the current query string.
                '$_GET'             => wp_json_encode( map_deep( wp_unslash( $_GET ), 'sanitize_text_field' ) ),
                'uncategorized'     => __( 'All Uncategorized', 'vergelabs-media-library' ),
                'reset_all_filters' => __( 'Reset All Filters', 'vergelabs-media-library' ),
                'filters_to_show'   => $vergeml_lib_options ? array_map( 'sanitize_key', $vergeml_lib_options['filters_to_show'] ) : array(
                    'types',
                    'dates',
                    'taxonomies'
                )
            );

            wp_localize_script(
                'vergeml-media-list-script',
                'vergeml_media_list_l10n',
                $media_list_l10n
            );
        }


        // scripts for grid view :: /wp-admin/upload.php
        if ( isset( $current_screen ) && 'upload' === $current_screen->base && 'grid' === $media_library_mode ) {

            wp_dequeue_script( 'media' );
        }
    }



    /**
     *  vergeml_register_scripts
     * 
     *  @todo :: make a separate one for Elementor if need be
     *
     *  @since    2.9.1
     *  @created  2024/05
     */

    add_action( 'wp_loaded', 'vergeml_register_scripts' );

    function vergeml_register_scripts() {

        global $vergeml_dir;


        /*
         *  Upstream shipped these two as minified-only and switched on an
         *  EML_SCRIPT_DEBUG constant to load js/source/, a directory that was
         *  never in the distribution. There was no readable copy of either
         *  file. They are now plain source, so there is nothing to switch.
         */

        wp_register_script(
            'vergeml-media-views-script',
            $vergeml_dir . 'js/vergeml-media-views.js',
            array('media-views'),
            VERGEML_VERSION,
            true
        );

        wp_register_script(
            'vergeml-taxonomies-options-script',
            $vergeml_dir . 'js/vergeml-taxonomies-options.js',
            array( 'jquery', 'underscore', 'vergeml-admin-script' ),
            VERGEML_VERSION,
            true
        );
    }



    /**
     *  vergeml_enqueue_media
     *
     *  @since    2.0
     *  @created  04/09/14
     */

    add_action( 'wp_enqueue_media', 'vergeml_enqueue_media' );

    function vergeml_enqueue_media() {

        global $vergeml_dir,
               $current_screen;


        if ( ! is_admin() ) {
            return;
        }


        $media_library_mode = get_user_option( 'media_library_mode', get_current_user_id() ) ? get_user_option( 'media_library_mode', get_current_user_id() ) : 'grid';

        $vergeml_lib_options = get_option( 'vergeml_lib_options' );
        $vergeml_taxonomies = get_option( 'vergeml_taxonomies', array() );
        $media_taxonomies = get_object_taxonomies( 'attachment','object' );
        $media_taxonomy_names = array_keys( $media_taxonomies );

        $media_taxonomies_ready_for_script = array();
        $filter_taxonomy_names_ready_for_script = array();
        $compat_taxonomies_to_hide = array();


        $terms = get_terms( array( 'taxonomy' => $media_taxonomy_names, 'fields' => 'all', 'get' => 'all' ) );
        $terms_id_tt_id_ready_for_script = vergeml_get_media_term_pairs( $terms, 'id=>tt_id' );


        $users_ready_for_script = array();

        if( current_user_can( 'manage_options' ) && $vergeml_lib_options ) {

            if ( in_array( 'authors', $vergeml_lib_options['filters_to_show'] ) ) {

                foreach( get_users( array( 'capability' => 'upload_files' ) ) as $user ) {
                    $users_ready_for_script[] = array(
                        'user_id' => $user->ID,
                        'user_name' => $user->data->display_name
                    );
                }
            }
        }


        if ( function_exists( 'wp_terms_checklist' ) ) {

            foreach ( $media_taxonomies as $taxonomy ) {

                $taxonomy_terms = array();


                ob_start();

                    wp_terms_checklist( 0, array( 'taxonomy' => $taxonomy->name, 'checked_ontop' => false, 'walker' => new Walker_Media_Taxonomy_Uploader_Filter() ) );

                    $html = '';
                    if ( ob_get_contents() != false ) {
                        $html = ob_get_contents();
                    }

                ob_end_clean();


                $html = str_replace( '}{', '},{', $html );
                $html = '[' . $html . ']';
                $taxonomy_terms = json_decode( $html, true );

                $media_taxonomies_ready_for_script[$taxonomy->name] = array(
                    'singular_name' => $taxonomy->labels->singular_name,
                    'plural_name'   => $taxonomy->labels->name,
                    'term_list'     => $taxonomy_terms,
                );


                if ( (bool) $vergeml_taxonomies[$taxonomy->name]['media_uploader_filter'] ) {
                    $filter_taxonomy_names_ready_for_script[] = $taxonomy->name;
                }

                if ( ! (bool) $vergeml_taxonomies[$taxonomy->name]['media_popup_taxonomy_edit'] ) {
                    $compat_taxonomies_to_hide[] = $taxonomy->name;
                }
            } // foreach
        }


        // generic scripts

        wp_enqueue_script(
            'vergeml-media-models-script',
            $vergeml_dir . 'js/eml-media-models.js',
            array('media-models'),
            VERGEML_VERSION,
            true
        );

        wp_enqueue_script( 'vergeml-media-views-script' );


        // TODO:
        // wp_enqueue_script(
        //     'vergeml-tags-box-script',
        //     '/wp-admin/js/tags-box.js',
        //     array(),
        //     VERGEML_VERSION,
        //     true
        // );


        $media_models_l10n = array(
            'media_orderby'   => $vergeml_lib_options ? sanitize_text_field( $vergeml_lib_options['media_orderby'] ) : 'date',
            'media_order'     => $vergeml_lib_options ? strtoupper( sanitize_text_field( $vergeml_lib_options['media_order'] ) ) : 'DESC',
            'bulk_edit_nonce' => wp_create_nonce( 'eml-bulk-edit-nonce' ),
            'natural_sort'    => (bool) $vergeml_lib_options['natural_sort'],
            'loads_per_page'  => (int) $vergeml_lib_options['loads_per_page']
        );

        wp_localize_script(
            'vergeml-media-models-script',
            'vergeml_media_models_l10n',
            $media_models_l10n
        );


        $media_views_l10n = array(
            'terms'                     => $terms_id_tt_id_ready_for_script,
            'taxonomies'                => $media_taxonomies_ready_for_script,
            'filter_taxonomies'         => $filter_taxonomy_names_ready_for_script,
            'compat_taxonomies'         => $media_taxonomy_names,
            'compat_taxonomies_to_hide' => $compat_taxonomies_to_hide,
            'is_tax_compat'             => count( $media_taxonomy_names ) - count( $compat_taxonomies_to_hide ) > 0 ? 1 : 0,
            'force_filters'             => (bool) $vergeml_lib_options['force_filters'],
            'filter_uploaded'           => (bool) $vergeml_lib_options['filter_uploaded'],
            'filters_to_show'           => $vergeml_lib_options ? array_map( 'sanitize_key', $vergeml_lib_options['filters_to_show'] ) : array(
                'types',
                'dates',
                'taxonomies'
            ),
            'users'                     => $users_ready_for_script,
            'uncategorized'             => __( 'All Uncategorized', 'vergelabs-media-library' ),
            'filter_by'                 => __( 'Filter by', 'vergelabs-media-library' ),
            'in'                        => __( 'All', 'vergelabs-media-library' ),
            'not_in'                    => __( 'Not in', 'vergelabs-media-library' ),
            'reset_filters'             => __( 'Reset All Filters', 'vergelabs-media-library' ),
            'author'                    => __( 'author', 'vergelabs-media-library' ),
            'authors'                   => __( 'authors', 'vergelabs-media-library' ),
            'current_screen'            => isset( $current_screen ) ? $current_screen->id : '',

            'saveButton_success'        => __( 'Saved.', 'vergelabs-media-library' ),
            'saveButton_failure'        => __( 'Something went wrong.', 'vergelabs-media-library' ),
            'saveButton_text'           => __( 'Save Changes', 'vergelabs-media-library' ),

            'select_all'                => __( 'Select All', 'vergelabs-media-library' ),
            'deselect'                  => __( 'Deselect ', 'vergelabs-media-library'),
            'grid_sidebar_width'        => (int) $vergeml_lib_options['grid_sidebar_width'],
            'ideal_column_width'        => (int) $vergeml_lib_options['ideal_column_width'],
        );

        wp_localize_script(
            'vergeml-media-views-script',
            'vergeml_mvln',
            $media_views_l10n
        );


        if ( vergeml_enhance_media_shortcodes() ) {

            wp_enqueue_script(
                'vergeml-enhanced-medialist-script',
                $vergeml_dir . 'js/eml-enhanced-medialist.js',
                array('media-views'),
                VERGEML_VERSION,
                true
            );

            wp_enqueue_script(
                'vergeml-media-editor-script',
                $vergeml_dir . 'js/eml-media-editor.js',
                array('media-editor','media-views', 'vergeml-enhanced-medialist-script'),
                VERGEML_VERSION,
                true
            );

            $enhanced_medialist_l10n = array(
                'uploaded_to' => __( 'Uploaded to post #', 'vergelabs-media-library' ),
                'based_on' => __( 'Based On', 'vergelabs-media-library' )
            );

            wp_localize_script(
                'vergeml-enhanced-medialist-script',
                'vergeml_enhanced_medialist_l10n',
                $enhanced_medialist_l10n
            );
        }


        // scripts for grid view :: /wp-admin/upload.php
        if ( isset( $current_screen ) && 'upload' === $current_screen->base && 'grid' === $media_library_mode ) {

            wp_enqueue_script(
                'vergeml-media-grid-script',
                $vergeml_dir . 'js/eml-media-grid.js',
                array( 'media-grid'),
                VERGEML_VERSION,
                true
            );

            wp_enqueue_script(
                'vergeml-media-script',
                $vergeml_dir . 'js/eml-media.js',
                array( 'media-grid' ),
                VERGEML_VERSION,
                true
            );
            
            $media_grid_l10n = array(
                'grid_show_caption' => (int) $vergeml_lib_options['grid_show_caption'],
                'grid_caption_type' => isset( $vergeml_lib_options['grid_caption_type'] ) ? sanitize_key( $vergeml_lib_options['grid_caption_type'] ) : 'title',
                'ideal_column_width' => (int) $vergeml_lib_options['ideal_column_width'],
                'more_details' => __( 'More Details', 'vergelabs-media-library' ),
                'less_details' => __( 'Less Details', 'vergelabs-media-library' )
            );

            wp_localize_script(
                'vergeml-media-grid-script',
                'vergeml_media_grid_l10n',
                $media_grid_l10n
            );
        }
    }



    /**
     *  vergeml_set_options
     *
     *  @since    2.6
     *  @created  02/05/18
     */

    function vergeml_set_options() {

        $vergeml_taxonomies  = get_option( 'vergeml_taxonomies' );
        $vergeml_lib_options = get_option( 'vergeml_lib_options', array() );
        $vergeml_tax_options = get_option( 'vergeml_tax_options', array() );


        // taxonomies
        if ( false === $vergeml_taxonomies ) {

            $vergeml_taxonomies = array(

                'media_category' => array(
                    'assigned' => 1,
                    'eml_media' => 1,

                    'labels' => array(
                        'name' => __( 'Media Categories', 'vergelabs-media-library' ),
                        'singular_name' => __( 'Media Category', 'vergelabs-media-library' ),
                        'menu_name' => __( 'Media Categories', 'vergelabs-media-library' ),
                        'all_items' => __( 'All Media Categories', 'vergelabs-media-library' ),
                        'edit_item' => __( 'Edit Media Category', 'vergelabs-media-library' ),
                        'view_item' => __( 'View Media Category', 'vergelabs-media-library' ),
                        'update_item' => __( 'Update Media Category', 'vergelabs-media-library' ),
                        'add_new_item' => __( 'Add New Media Category', 'vergelabs-media-library' ),
                        'new_item_name' => __( 'New Media Category Name', 'vergelabs-media-library' ),
                        'parent_item' => __( 'Parent Media Category', 'vergelabs-media-library' ),
                        'parent_item_colon' => __( 'Parent Media Category:', 'vergelabs-media-library' ),
                        'search_items' => __( 'Search Media Categories', 'vergelabs-media-library' )
                    ),

                    'hierarchical' => 1,

                    'show_admin_column' => 1,
                    'admin_filter' => 1,          // list view filter
                    'media_uploader_filter' => 1, // grid view filter
                    'media_popup_taxonomy_edit' => 0, // since 2.7

                    'sort' => 0,
                    'show_in_rest' => 0,
                    'rewrite' => array(
                        'slug' => 'media_category',
                        'with_front' => 1
                    )
                )
            );
        }

        // false !== $vergeml_taxonomies
        else {

            $media_taxonomy_args_defaults = array(
                'assigned' => 1,
                'eml_media' => 1,
                'labels' => array(),

                'hierarchical' => 1,
                'show_admin_column' => 1,
                'admin_filter' => 1,          // list view filter
                'media_uploader_filter' => 1, // grid view filter
                'media_popup_taxonomy_edit' => 0, // since 2.7

                'sort' => 0,
                'show_in_rest' => 0,
                'rewrite' => array(
                    'slug' => '',
                    'with_front' => 1
                )
            );

            $non_media_taxonomy_args_defaults = array(
                'assigned' => 0,
                'eml_media' => 0,
                'admin_filter' => 1, // since 2.7
                'media_uploader_filter' => 1, // since 2.7
                'media_popup_taxonomy_edit' => 0,
                'taxonomy_auto_assign' => 0
            );


            foreach( $vergeml_taxonomies as $taxonomy => $params ) {

                if ( empty( $params['eml_media'] ) ) {
                    $vergeml_taxonomies[$taxonomy]['eml_media'] = 0;
                }

                $defaults = (bool) $vergeml_taxonomies[$taxonomy]['eml_media'] ? $media_taxonomy_args_defaults : $non_media_taxonomy_args_defaults;

                $taxonomy_params = array_intersect_key( $params, $defaults );
                $vergeml_taxonomies[$taxonomy] = array_merge( $defaults, $taxonomy_params );

                if ( (bool) $vergeml_taxonomies[$taxonomy]['eml_media'] && empty( $params['rewrite']['slug'] ) ) {
                    $vergeml_taxonomies[$taxonomy]['rewrite']['slug'] = $taxonomy;
                }
            } // foreach
        } // if

        update_option( 'vergeml_taxonomies', $vergeml_taxonomies );


        // media library options
        $eml_lib_options_defaults = array(
            'enhance_media_shortcodes' => isset( $vergeml_tax_options['enhance_media_shortcodes'] ) ? (bool) $vergeml_tax_options['enhance_media_shortcodes'] : ( isset( $vergeml_tax_options['enhance_gallery_shortcode'] ) ? (bool) $vergeml_tax_options['enhance_gallery_shortcode'] : 0 ),
            'media_orderby' => isset( $vergeml_tax_options['media_orderby'] ) ? sanitize_text_field( $vergeml_tax_options['media_orderby'] ) : 'date',
            'media_order' => isset( $vergeml_tax_options['media_order'] ) ? strtoupper( sanitize_text_field( $vergeml_tax_options['media_order'] ) ) : 'DESC',
            'natural_sort' => 0,
            'force_filters' => isset( $vergeml_tax_options['force_filters'] ) ? (bool) $vergeml_tax_options['force_filters'] : 1,
            'filters_to_show' => array(
                'types',
                'dates',
                'taxonomies'
            ),
            'show_count' => isset( $vergeml_tax_options['show_count'] ) ? (bool) $vergeml_tax_options['show_count'] : 1,
            'include_children' => 1,
            'filter_uploaded' => 0,
            'infinite_scrolling' => 0,
            'loads_per_page' => 80,
            'grid_show_caption' => 0,
            'grid_caption_type' => 'title',
            'grid_sidebar_width' => 270,
            'ideal_column_width' => 170,
            'search_in' => array(
                'filenames',
                'titles',
                'captions',
                'descriptions'
            ),
            'search_min_letters' => 2,
            'search_on_enter' => 0,
            'search_auto' => 1
        );

        $vergeml_lib_options = array_intersect_key( $vergeml_lib_options, $eml_lib_options_defaults );
        $vergeml_lib_options = array_merge( $eml_lib_options_defaults, $vergeml_lib_options );

        // check previous version
        if ( version_compare( get_option( 'vergeml_version', '' ), '2.8.9', '<=' ) ) {
            // ensure that filenames included in the search by default
            array_push( $vergeml_lib_options['search_in'], 'filenames' );
        }

        update_option( 'vergeml_lib_options', $vergeml_lib_options );


        // taxonomy options
        $eml_tax_options_defaults = array(
            'tax_archives' => 0, // since 2.6
            'edit_all_as_hierarchical' => 0,
            'bulk_edit_save_button' => 0 // since 2.7
        );

        $vergeml_tax_options = array_intersect_key( $vergeml_tax_options, $eml_tax_options_defaults );
        $vergeml_tax_options = array_merge( $eml_tax_options_defaults, $vergeml_tax_options );

        update_option( 'vergeml_tax_options', $vergeml_tax_options );


        // MIME types
        if ( false === get_option( 'vergeml_mimes' ) ) {

            $allowed_mimes = get_allowed_mime_types();

            foreach ( wp_get_mime_types() as $ext => $type ) {
                $vergeml_mimes[$ext] = array(
                    'mime'     => $type,
                    'singular' => $type,
                    'plural'   => $type,
                    'filter'   => 0,
                    'upload'   => isset($allowed_mimes[$ext]) ? 1 : 0
                );
            }

            update_option( 'vergeml_mimes', $vergeml_mimes );
        }

        if ( version_compare( get_option( 'vergeml_version', '' ), '2.8.9', '<=' ) ) {
            // getting rid of mime type backup
            delete_site_option( 'vergeml_mimes_backup' );
        }

        do_action( 'vergeml_set_options' );
    }



    /**
     *  vergeml_set_network_options
     *
     *  @since    2.6.3
     *  @created  21/05/18
     */

    function vergeml_set_network_options() {

        $vergeml_network_options = get_site_option( 'vergeml_network_options', array() );

        $vergeml_network_options_defaults = array(
            'media_settings' => 1,
            'utilities' => 1
        );

        $vergeml_network_options = array_intersect_key( $vergeml_network_options, $vergeml_network_options_defaults );
        $vergeml_network_options = array_merge( $vergeml_network_options_defaults, $vergeml_network_options );

        update_site_option( 'vergeml_network_options', $vergeml_network_options );
    }



    /**
     *  vergeml_settings_link
     *
     *  Add settings link to the plugin action links
     *
     *  @since    2.1
     *  @created  27/10/15
     */

    function vergeml_settings_link( $actions ) {

        $settings_page = is_network_admin() ? 'settings.php' : 'options-general.php';

        if ( ! is_network_admin() ) {
            $custom_links['settings'] = '<a href="' . self_admin_url($settings_page.'?page=media') . '">' . __( 'Media Settings', 'vergelabs-media-library' ) . '</a>';
        }

        $custom_links['utility'] = '<a href="' . self_admin_url($settings_page.'?page=eml-settings') . '">' . __( 'Utilities', 'vergelabs-media-library' ) . '</a>';

        return array_merge( $custom_links, $actions );
    }



    /**
     *  vergeml_plugin_row_meta
     *
     *  @since    2.2.1
     *  @created  11/04/15
     */

    function vergeml_plugin_row_meta( $plugin_meta, $plugin_file ) {

        if ( vergeml_get_basename() !== $plugin_file ) {
            return $plugin_meta;
        }

        $plugin_meta[] = '<a href="https://wpuxsolutions.com/documents/enhanced-media-library" target="_blank">' . __( 'Docs', 'vergelabs-media-library' ) . '</a>';
        $plugin_meta[] = '<a href="https://wpuxsolutions.com/support" target="_blank">' . __( 'Support', 'vergelabs-media-library' ) . '</a>';

        if ( ! defined( 'EML_IS_PRO' ) ) {

            $plugin_meta[] = '<a href="https://wpuxsolutions.com/plugins/enhanced-media-library-pro" class="eml-pro" target="_blank">' . __( 'Go PRO', 'vergelabs-media-library' ) . '</a>';
        }

        $plugin_meta[] = '<a href="https://wpuxsolutions.com/plugins/enhanced-media-library-3-0" class="eml-pro" target="_blank">' . __( '3.0 Beta', 'vergelabs-media-library' ) . '</a>';

        return $plugin_meta;
    }



    /**
     *  Enable Infinite Scrolling
     *
     *  @since    2.9
     *  @created  09/2021
     */

    if ( vergeml_enable_infinite_scrolling() ) {
        add_filter( 'media_library_infinite_scrolling', '__return_true' );
    }



    /**
     *  Free functionality
     */

    include_once( 'core/mime-types.php' );
    include_once( 'core/taxonomies.php' );
    include_once( 'core/media-templates.php' );
    include_once( 'core/compatibility.php' );
    include_once( 'core/search.php' );
    include_once( 'core/auto-assign.php' );
    include_once( 'core/bulk-terms.php' );

    if ( vergeml_enhance_media_shortcodes() ) {
        include_once( 'core/medialist.php' );
    }

    if ( is_admin() ) {
        include_once( 'core/options-pages.php' );
    }

}
